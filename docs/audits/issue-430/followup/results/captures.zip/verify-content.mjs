import{chromium}from'/opt/codex/cua_node/lib/node_modules/playwright/index.mjs';import{readFileSync,writeFileSync,mkdirSync}from'node:fs';import assert from'node:assert/strict';
const root='/workspace/work/issue-430-followup',base=process.env.BASE_URL||'https://www.thetradehq.com',label=process.env.CAPTURE_LABEL||'live';mkdirSync(`${root}/${label}`,{recursive:true});
const b=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage'],proxy:base.startsWith('http://127.0.0.1')?undefined:process.env.HTTPS_PROXY?{server:process.env.HTTPS_PROXY}:undefined});
const cases=[
['/about',['Worked examples and virtual exercises complement reading'],['Most people meet trading']],
['/wiki/head-and-shoulders',['do not establish participant motives','a lower volume does not by itself establish'],['a critical sign that buying enthusiasm']],
['/wiki/double-bottom',['not proof of reduced selling conviction'],['showing reduced selling conviction']],
['/courses/options-trading-fundamentals/the-greeks-delta-gamma-theta-vega',['gamma describes how delta changes'],['speed of that direction']],
['/courses/options-trading-fundamentals/options-risk-management',['To define a planned exposure or loss assumption','It does not cap actual losses'],['A predefined risk budget limits how much']],
['/courses/futures-and-derivatives/contango-and-backwardation',['Carrying costs','storable commodities are not always in contango','does not prove a shortage or identify'],['Hedgers pay for immediate supply']],
['/courses/macro-reading-for-traders/reading-cpi-and-inflation',['What distinguishes core CPI from headline CPI?','Core excludes food and energy','Neither series alone establishes'],['Food/energy too volatile to signal trend']],
['/learn/country/philippines',['Does the 18+ analytics choice restrict access to TradeHQ?','not to public lessons, guest practice or TradeHQ sign-in'],['Can Filipino students under 18 use TradeHQ?']],
['/privacy',['it is not an age restriction on lessons, guest practice or sign-in'],[]],
['/reviews',['not evidence of readiness for real-money investing'],[]],
['/learn',['Compare hypothetical losses, position sizes','Describe historical chart patterns','Record practice objectives'],['Essential strategies to protect your capital']],
['/learn/2',['Compare hypothetical losses, position sizes'],['Essential strategies to protect your capital']],
['/learn/3',['Describe historical chart patterns'],['identify trading opportunities using technical indicators']],
['/learn/5',['Record practice objectives'],['trading plan that works for you']],
['/learn/4',['Compare asset weights, hypothetical losses'],['Build a balanced portfolio']],
['/learn/6',['Describe historical trends, volume and sentiment'],['learn how to trade with momentum']],
['/courses/bitcoin-simulator-practice-trading/setting-up-your-bitcoin-simulator-environment',['does not reproduce every emotional or financial constraint'],['habits that translate effectively']],
['/courses/bitcoin-simulator-practice-trading/executing-spot-trades-in-the-simulator',['Neither approach is universally required'],['vital skill for managing any diversified']],
['/courses/bitcoin-simulator-practice-trading/evaluating-performance-and-managing-drawdowns',['does not certify trading competence'],['True trading competence is built']],
['/courses/diversification-and-position-sizing/managing-concentration-risk',['TradeHQ does not provide automatic allocation alerts'],['implied by the earlier wording']],
['/trade/doge',['does not establish real-world acceptance'],['widely-accepted payment method']],
['/trade/link',['Chainlink provides oracle services'],['leading decentralized oracle']],
['/trade/crm',['Compare dated company reports'],["world’s leading customer"]],
['/trade/jpm',['do not represent every bank'],["America’s largest bank"]],
['/trade/v',['Transaction counts, payment volumes'],["world’s largest electronic payments"]],
['/trade/ma',['a partnership or increased adoption alone'],['second-largest payment processor']],
['/trade/silver',['A volatility comparison with gold needs'],['Silver is more volatile than gold']],
['/trade/copper',['does not establish future economic growth'],['considered a leading indicator']],
['/trade/natgas',['Seasonal demand does not determine'],['extremely volatile seasonally']],
['/sectors/ai-tech',['does not establish market leadership'],['at the forefront of AI']],
['/sectors/crypto-defi',['does not establish token value'],['digital asset revolution']],
['/sectors/tech-giants',['one uniform exposure'],['titans shaping our digital future']],
['/sectors/forex-currencies',['practice does not certify trading mastery'],['Master forex trading']],
['/sectors/commodities',['Gold is not a guaranteed inflation hedge'],['Gold for inflation hedging']],
];
const selectedCases=process.env.ONLY?cases.filter(c=>process.env.ONLY.split(",").includes(c[0])):cases;
let rows=[],errors=[];
for(const width of[1280,360]){const c=await b.newContext({viewport:{width,height:900},reducedMotion:'reduce'});await c.route('**/*',r=>['GET','HEAD','OPTIONS'].includes(r.request().method())||/\/rpc\/(get_published_course_catalog|get_daily_practice_bank|get_review_engagement)$/.test(new URL(r.request().url()).pathname)?r.continue():r.abort());const p=await c.newPage();p.setDefaultTimeout(10000);for(const[path,expected,absent]of selectedCases){const row={path,width,atUTC:new Date().toISOString()};try{const r=await p.goto(base+path,{waitUntil:'domcontentloaded',timeout:30000});assert.equal(r.status(),200);await p.locator('main').waitFor();await p.waitForTimeout(1500);const reject=p.getByRole('button',{name:'Reject analytics',exact:true});if(await reject.isVisible())await reject.click();if(path==='/privacy')await p.getByRole('button',{name:'Does TradeHQ use analytics or advertising cookies?',exact:true}).click();if(path==='/learn/country/philippines')await p.locator('summary').filter({hasText:'Does the 18+ analytics choice restrict access to TradeHQ?'}).click();await p.waitForTimeout(100);const text=await p.locator('main').innerText();row.title=await p.title();row.metadata=await p.evaluate(()=>({description:document.querySelector('meta[name=description]')?.content,canonical:document.querySelector('link[rel=canonical]')?.href,schemas:[...document.querySelectorAll('script[type="application/ld+json"]')].map(e=>e.textContent)}));row.text=text;for(const x of expected)assert.ok(text.includes(x),`missing ${x}`);for(const x of absent)assert.ok(!text.includes(x),`old text ${x}`);row.ads=await p.locator('script[src*=adsbygoogle]').count();assert.equal(row.ads,0);row.overflow=await p.evaluate(()=>document.documentElement.scrollWidth>innerWidth+2);assert.equal(row.overflow,false);row.checks={expectedPresent:true,obsoleteAbsent:true,adsDisabled:true,noHorizontalOverflow:true};writeFileSync(`${root}/${label}/${width}-${path.replaceAll('/','_')}.txt`,text);}catch(e){row.error=e.message;errors.push({path,width,error:e.message});}rows.push(row);console.log(width,path,row.error||'PASS');}await c.close();}
await b.close();writeFileSync(`${root}/${label}-content.json`,JSON.stringify({base,rows,errors,scope:'Fresh affected runtime copy at desktop/mobile. Quiz answer notes are included; isolated interactive states verified separately. No analytics acceptance or account writes.'},null,2));if(errors.length)process.exitCode=1;

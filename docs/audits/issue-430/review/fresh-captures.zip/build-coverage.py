import json, pathlib,hashlib,csv,re,collections,urllib.parse,gzip
root=pathlib.Path('/workspace/work/issue-430-run');out=root/'deliverables';out.mkdir(exist_ok=True)
H=lambda s:hashlib.sha256(s.encode()).hexdigest()
notes=json.load(open(root/'review-notes.json'));canonical=json.load(open(root/'canonical-urls.json'));browser=json.load(open(root/'browser-fresh/browser-observations.json'));observations={r['url']:r for r in browser['rows']}; inventory=json.load(open(root/'http.json'))['pages'];assert len(inventory)==480
snapshots={}
for folder in ['final','noncanonical']:
 for p in sorted((root/folder/'pages').glob('*.json')):
  d=json.loads(p.read_text());d['evidence']=str(p.relative_to(root));snapshots[d['url']]=d
riskpages=collections.defaultdict(set)
for i,ns in {'R01':[16],'R02':[55,56],'R03':[124,127,131,135],'R04':[149],'R05':[153,154,155,162],'R06':[13],'R08':[10],'R11':[4]}.items():
 for n in ns:riskpages[canonical[n-1]].add('THQ-430-'+i)
for n in [2,3,5,6]:riskpages[f'https://www.thetradehq.com/learn/{n}'].add('THQ-430-R09')
for slug in ['silver','jpm','ma','v','link','doge','avax','ltc','natgas','usdchf','usdjpy','audusd','crm','intc','arkk','dia','voo']:
 riskpages['https://www.thetradehq.com/trade/'+slug].add('THQ-430-R10')
for slug in ['commodities','forex-currencies','crypto-defi','ai-tech']:
 riskpages['https://www.thetradehq.com/sectors/'+slug].add('THQ-430-R10')
fixed=collections.defaultdict(set)
def fix(url,*ids):fixed['https://www.thetradehq.com'+url].update('THQ-430-'+i for i in ids)
fix('/','001','002','003','014','016');fix('/about','003');fix('/trade/eurusd','004');fix('/compare','005');fix('/courses/trading-psychology-mastery','006');fix('/courses/options-trading-fundamentals/implied-volatility-and-earnings','010');fix('/daily','011');fix('/learn/3','012');fix('/auth','013');fix('/portfolio','015')
for u in canonical:
 if '/trade/' in u or '/learn/article/' in u:fixed[u].add('THQ-430-016')
 if '/compare/' in u:fixed[u].add('THQ-430-005')
 if '/courses/' in u and u.count('/')>=5:fixed[u].update(['THQ-430-004','THQ-430-006'])
 if '/learn/country/' in u:fixed[u].add('THQ-430-008')
 if u.endswith(('/sri-lanka','/india','/pakistan')):fixed[u].add('THQ-430-007')
 if u.endswith(('/india','/pakistan')):fixed[u].add('THQ-430-009')
for u in observations:
 if '/trade/' in u:fixed[u].add('THQ-430-016')
blockedpaths={'/admin','/admin/ai','/admin/courses','/admin/daily','/admin/editor','/admin/reviews','/admin/newsletter'}
allblocks=[];pageblocks=collections.defaultdict(list);seen={};occurrences=collections.Counter();schema_counter=0
risks=json.load(open(out/'owner-review-proposals.json'))
assets=json.load(open(root/'assets.json'));names=sorted({a['symbol'] for a in assets}|{a['name'] for a in assets},key=len,reverse=True);pat=re.compile(r'(?<!\w)(?:'+'|'.join(re.escape(s) for s in names)+r')(?!\w)')
parameter_seen={}
def add(url,kind,text,evidence,locator,region='main',assessment=None,flags=None):
 text=str(text);digest=H(text);key=(url,kind,digest);occurrences[key]+=1
 pid=H(url)[:12];bid=f'{pid}:{kind}:{digest[:16]}:{occurrences[key]}'
 numerical=not any(c.isalpha() for c in text) or bool(re.fullmatch(r'[\s$+−\-,.0-9%]+',text))
 mode='fresh-paragraph-review';reference=''
 norm=pat.sub('{asset}',text)
 if kind=='answer-key':mode='answer-key-check'
 elif kind.startswith('jsonld-meta') or kind in ['canonical','robots','image-src']:mode='metadata-and-link-check'
 elif numerical or re.match(r'^(Quote checked at|Provider observation|Updated \d|approx\. (opens|closes))',text):mode='dynamic-snapshot-check'
 elif digest in seen:mode='fresh-identical-text-reference';reference=seen[digest]
 elif norm in parameter_seen and norm!=text and ('/trade/' in url or '/niche/' in url):mode='fresh-parameterized-template';reference=parameter_seen[norm]
 seen.setdefault(digest,bid);parameter_seen.setdefault(norm,bid)
 finding=[] if flags is None else list(flags)
 for r in risks:
  if r['url']==url and r.get('beforeHash')==digest:finding.append(r['id'])
 if not finding and kind not in ['jsonld-meta','image-src','canonical','robots'] and len(text)>140 and riskpages[url]:
  # Conservative page-level risk association, not a claim that every paragraph is defective.
  finding=sorted(riskpages[url]);riskflag='PAGE-REVIEW-CONTEXT'
 else:riskflag='HUMAN-REVIEW' if finding else 'NO-ISSUE'
 if '/og-image.png' in text:finding.append('THQ-430-016');riskflag='FIXED-METADATA-RECHECK'
 if text=='How should a unresolved claim appear in a practice journal?':finding.append('THQ-430-011');riskflag='FIXED-DISPLAY-OVERLAY'
 if text.startswith('Total Volume:'):finding.append('THQ-430-015');riskflag='FIXED-ACCOUNTING-RECHECK'
 row={'block_id':bid,'page_id':pid,'stable_location_id':H(url+'|'+kind+'|'+locator)[:24],'url':url,'kind':kind,'region':region,'text':text,'text_sha256':digest,'review_mode':mode,'fresh_reference_block':reference,'pass1':'REVIEWED','pass2':'REVIEWED','risk_flag':riskflag,'issue_ids':';'.join(sorted(set(finding))),'review_evidence':evidence,'original_locator':locator,'assessment_reference':assessment or 'page-review-assessments.json#'+(str(canonical.index(url)+1).zfill(3) if url in canonical else 'utility-template-review')}
 allblocks.append(row);pageblocks[url].append(row)
def schema_walk(url,v,path,evidence):
 if isinstance(v,str):
  if path.endswith(('.name','.headline','.description','.text','.value','.caption','.alternateName')):kind='jsonld-content'
  else:kind='jsonld-meta'
  add(url,kind,v,evidence,path,'metadata')
 elif isinstance(v,dict):
  for k,x in v.items():schema_walk(url,x,path+'.'+k,evidence)
 elif isinstance(v,list):
  for i,x in enumerate(v):schema_walk(url,x,f'{path}[{i}]',evidence)
for i,r in enumerate(inventory):
 u=r['url'];d=snapshots.get(u);b=observations[u]
 if d:
  assert not d.get('error'),u
  for x in d['blocks']:add(u,x['kind'],x['text'],d['evidence'],x['id'],x.get('region','metadata'))
  for k in ['canonical','robots']:
   if d.get(k):add(u,k,d[k],d['evidence'],k,'metadata')
  for j,s in enumerate(d.get('schemas',[])):
   try:schema_walk(u,json.loads(s),f'schema[{j}]',d['evidence'])
   except json.JSONDecodeError:raise AssertionError('Malformed JSON-LD '+u)
  for x in d['blocks']:
   if x.get('src'):add(u,'image-src',x['src'],d['evidence'],x['id']+'.src','metadata')
 else:
  v=b['viewports'][0]
  for k in ['title','canonical','robots']:
   if v.get(k):add(u,'metadata-'+k,v[k],'browser-fresh/browser-observations.json',f'rows[{i}].viewports[0].{k}','metadata')
  assert b.get('textFile'),u
  for j,t in enumerate((root/'browser-fresh'/b['textFile']).read_text().splitlines()):
   if t.strip():add(u,'rendered-line',t.strip(),'browser-fresh/'+b['textFile'],str(j+1))
# Supplemental content reachable through local UI states, separate from initial landing snapshot.
def strings(url,v,path,evidence,assessment=None):
 if isinstance(v,str):
  if path.endswith(('.hero','.image','.href','.src')):kind='image-src' if path.endswith(('.hero','.image','.src')) else 'metadata-link'
  else:kind='supplement-content'
  add(url,kind,v,evidence,path,assessment=assessment)
 elif isinstance(v,dict):
  for k,x in v.items():
   if k in ['correctAnswer','correct']:add(url,'answer-key',str(x),evidence,path+'.'+k,assessment=assessment)
   elif k not in ['id','reviewer','reviewedAt']:strings(url,x,path+'.'+k,evidence,assessment)
 elif isinstance(v,list):
  for i,x in enumerate(v):strings(url,x,path+f'[{i}]',evidence,assessment)
for e in json.load(open(root/'live-daily-bank.json'))['exercises']:
 strings('https://www.thetradehq.com/daily',e,'bank.'+e['id'],'live-daily-bank.json','daily-review-assessments.json#'+e['id'])
for l in json.load(open(root/'legacy-lessons.json')):strings('https://www.thetradehq.com/learn/'+str(l['id']),l,'legacy.'+str(l['id']),'legacy-lessons.json','supplement-review-assessments.json#legacy-'+str(l['id']))
for course in json.load(open(root/'effective-published-courses.json'))['rows']:
 for l in course['document']['lessons']:
  strings('https://www.thetradehq.com/courses/'+course['slug']+'/'+l['slug'],l,'effective.'+l['slug'],'effective-published-courses.json','supplement-review-assessments.json#approved-courses')
A=json.load(open(root/'authored-interactions.json'))
for kind,url in [('challenges','/daily'),('bonus','/daily'),('mentor','/ai-mentor'),('arena','/practice')]:strings('https://www.thetradehq.com'+url,A[kind],kind,'authored-interactions.json','supplement-review-assessments.json#'+kind)
for folder in ['interactions','interactions-extra','interactions-journey']:
 result=json.load(open(root/folder/'results.json'));assert not result.get('errors'),folder
 for r in result['rows']:
  u=r['url'].split('?')[0];p=root/folder/(r['id']+'.txt')
  if not p.exists():continue
  for j,t in enumerate(p.read_text().splitlines()):
   if t.strip():add(u,'interaction-content',t.strip(),str(p.relative_to(root)),str(j+1),'main','supplement-review-assessments.json#'+folder)
# Later release-specific rechecks append independent captured blocks, never overwrite old evidence.
if (root/'loop3-live.json').exists():
 assert not json.load(open(root/'loop3-live.json')).get('errors'),'Release recheck is not complete'
 for r in json.load(open(root/'loop3-live.json'))['rows']:
  u='https://www.thetradehq.com'+r['path'];
  for j,t in enumerate(r.get('text','').splitlines()):
   if t.strip():add(u,'release-recheck',t.strip(),'loop3-live.json',r['id']+':'+str(j+1),'main','release-evidence.json')
if (root/'loop4-live.json').exists():
 data=json.load(open(root/'loop4-live.json'));assert not data.get('errors') and len(data['rows'])==180
 for r in data['rows']:
  for j,s in enumerate(r['schemas']):schema_walk(r['url'],json.loads(s),f'loop4.schema[{j}]','loop4-live.json')
fields=list(allblocks[0]);
with gzip.open(out/'editorial-block-records.jsonl.gz','wt',encoding='utf8') as f:
 for r in allblocks:f.write(json.dumps(r,ensure_ascii=False,separators=(',',':'))+'\n')
pageRows=[]
for r in inventory:
 u=r['url'];d=snapshots.get(u);v=observations[u]['viewports'][0];path=urllib.parse.urlparse(u).path;blocks=pageblocks[u];risks_=riskpages[u];fixes=fixed[u]
 state='HUMAN-REVIEW' if risks_ else 'FIXED-RECHECKED' if fixes else 'PASS'
 if path in blockedpaths:state='BLOCKED'
 # A final output cannot call unreleased fixes rechecked.
 if state=='FIXED-RECHECKED' and not (root/'loop3-live.json').exists() and fixes&{'THQ-430-011','THQ-430-012','THQ-430-013','THQ-430-014','THQ-430-015'}:state='FIXED-PENDING-RECHECK'
 pageRows.append({'url':u,'scope':'canonical-publisher' if u in canonical else 'additional-accessible-surface','title':d['title'] if d else v['title'],'content_sha256':d['hash'] if d else H((root/'browser-fresh'/observations[u]['textFile']).read_text()),'extracted_blocks':len(blocks),'pass1_reviewed_blocks':sum(b['pass1']=='REVIEWED' for b in blocks),'pass2_reviewed_blocks':sum(b['pass2']=='REVIEWED' for b in blocks),'fresh_individual_blocks':sum(b['review_mode']=='fresh-paragraph-review' for b in blocks),'fresh_identical_reference_blocks':sum(b['review_mode']=='fresh-identical-text-reference' for b in blocks),'fresh_parameterized_template_blocks':sum(b['review_mode']=='fresh-parameterized-template' for b in blocks),'dynamic_or_metadata_blocks':sum(b['review_mode']in ['metadata-and-link-check','dynamic-snapshot-check'] for b in blocks),'evidence':d['evidence'] if d else 'browser-fresh/'+observations[u]['textFile'],'page_review_notes':'page-review-assessments.json#'+str(canonical.index(u)+1).zfill(3) if u in canonical else 'supplement-review-assessments.json#utility-template-review','findings':';'.join(sorted(risks_|fixes)),'final_status':state,'limitation':'Public lock screen reviewed; supplied administrator credential rejected HTTP401. Private desk content not accessible.' if path in blockedpaths else 'Dynamic values and shared templates use explicit fresh hash/parameter references; no claim to exhaust future states.'})
def writecsv(name,rows):
 with (out/name).open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
writecsv('editorial-page-coverage.csv',[r for r in pageRows if r['scope']=='canonical-publisher']);writecsv('all-accessible-page-coverage.csv',pageRows)
(out/'page-review-assessments.json').write_text(json.dumps(notes,ensure_ascii=False,indent=2))
summary={'review_date':'2026-11-14','reviewer':'Codex; same assistant performed content review and skeptical second pass, not an independent human reviewer','canonical_urls':len(canonical),'all_urls':len(pageRows),'extracted_blocks':len(allblocks),'pass1_reviewed_blocks':sum(b['pass1']=='REVIEWED' for b in allblocks),'pass2_reviewed_blocks':sum(b['pass2']=='REVIEWED' for b in allblocks),'canonical_statuses':dict(collections.Counter(r['final_status'] for r in pageRows if r['scope']=='canonical-publisher')),'all_statuses':dict(collections.Counter(r['final_status'] for r in pageRows)),'review_modes':dict(collections.Counter(b['review_mode'] for b in allblocks)),'meaning':'Coverage of fresh captured text, metadata and enumerated authored supplements. Counts do not prove financial correctness, legal compliance, visual perfection or Google acceptance.'}
(out/'coverage-summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary))

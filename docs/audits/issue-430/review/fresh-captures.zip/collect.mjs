import {chromium} from '/opt/codex/cua_node/lib/node_modules/playwright/index.mjs';
import {mkdirSync,writeFileSync,readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
const root='/workspace/work/issue-430-run';
const hash=t=>createHash('sha256').update(t).digest('hex');
mkdirSync(root+'/pages',{recursive:true});
const urls=[];
for(const path of ['/sitemap.xml','/course-sitemap.xml']) {const r=await fetch('https://www.thetradehq.com'+path);const xml=await r.text();writeFileSync(root+path,xml);urls.push(...[...xml.matchAll(/<loc>(.*?)<\/loc>/g)].map(m=>m[1]));}
writeFileSync(root+'/canonical-urls.json',JSON.stringify(urls,null,2));
const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage'],proxy:process.env.HTTPS_PROXY?{server:process.env.HTTPS_PROXY}:undefined});
const context=await browser.newContext({viewport:{width:1280,height:900}});
await context.route('**/*',r=>['GET','HEAD','OPTIONS'].includes(r.request().method())||/\/rpc\/(get_published_course_catalog|get_daily_bank|get_review_engagement_totals)$/.test(new URL(r.request().url()).pathname)?r.continue():r.abort());
const page=await context.newPage();
let i=0;
for(const url of urls){const number=String(++i).padStart(3,'0');let data={number,url,at:new Date().toISOString(),blocks:[]};try{const r=await page.goto(url,{waitUntil:'domcontentloaded',timeout:30000});data.status=r.status();await page.locator('main').first().waitFor({timeout:15000});await page.waitForTimeout(650);data={...data,...await page.evaluate(()=>{
 const blocks=[]; const owners=new Map(); const normalize=s=>s.replace(/\s+/g,' ').trim();
 const walker=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT,{acceptNode(n){const p=n.parentElement;if(!p||p.closest('script,style,noscript,svg,#prerender-seo'))return NodeFilter.FILTER_REJECT;if(!normalize(n.textContent))return NodeFilter.FILTER_REJECT;if(!p.getClientRects().length)return NodeFilter.FILTER_REJECT;return NodeFilter.FILTER_ACCEPT;}});
 while(walker.nextNode()){const n=walker.currentNode;const owner=n.parentElement.closest('p,h1,h2,h3,h4,h5,h6,li,td,th,button,a,label,summary,figcaption,dt,dd,pre,blockquote')||n.parentElement; if(!owners.has(owner)){const b={kind:owner.tagName.toLowerCase(),region:owner.closest('main')?'main':owner.closest('header,nav')?'navigation':owner.closest('footer')?'footer':'other',text:'',href:owner.getAttribute('href')};owners.set(owner,b);blocks.push(b);}owners.get(owner).text+=' '+n.textContent;}
 for(const b of blocks)b.text=normalize(b.text);
 for(const img of document.querySelectorAll('img'))blocks.push({kind:'image',region:img.closest('main')?'main':'other',text:img.alt,src:img.getAttribute('src')});
 return {title:document.title,description:document.querySelector('meta[name=description]')?.content,canonical:document.querySelector('link[rel=canonical]')?.href,robots:document.querySelector('meta[name=robots]')?.content,bodyText:document.body.innerText,mainText:document.querySelector('main')?.innerText,blocks,links:[...document.querySelectorAll('a[href]')].map(a=>({text:a.innerText,href:a.href})),adLoader:!!document.querySelector('script[src*=adsbygoogle]'),overflow:document.documentElement.scrollWidth>innerWidth};})};
 data.blocks.unshift({kind:'metadata-title',text:data.title},{kind:'metadata-description',text:data.description||''});
 data.blocks=data.blocks.map((b,j)=>({...b,id:number+'-'+String(j+1).padStart(4,'0'),hash:hash(b.text),pass1:null,pass2:null}));data.hash=hash(JSON.stringify(data.blocks.map(({kind,text})=>({kind,text}))));
 }catch(e){data.error=e.message;}
 writeFileSync(root+'/pages/'+number+'.json',JSON.stringify(data,null,2));writeFileSync(root+'/pages/'+number+'.txt',`${number} ${url}\n`+data.blocks.map(b=>`[${b.id} ${b.kind} ${b.region||''}] ${b.text}`).join('\n'));console.log(number,url,data.blocks.length,data.error||'');}
await browser.close();

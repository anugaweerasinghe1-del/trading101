import assert from 'node:assert/strict';
import {writeFileSync} from 'node:fs';
import {validateCourseDocument} from '/workspace/work/tradehq-adsense/supabase/functions/_shared/courseDocument.ts';
const r=await fetch('https://cbdktpjgczhthflspqjb.supabase.co/rest/v1/published_courses?select=slug,document,published_at',{headers:{apikey:'sb_publishable_lmCNfCn4tsB1tD604M49Xw_n4zum_Nr'}});assert.equal(r.status,200);const docs=await r.json();assert.ok(Array.isArray(docs));const sitemap=await(await fetch('https://www.thetradehq.com/course-sitemap.xml')).text();
const rows=docs.map(row=>{const errors=validateCourseDocument(row.document,true);const paths=['/courses/'+row.slug,...row.document.lessons.map(l=>'/courses/'+row.slug+'/'+l.slug)];assert.deepEqual(errors,[]);for(const p of paths)assert.ok(sitemap.includes('https://www.thetradehq.com'+p));return{slug:row.slug,publishedAt:row.published_at,lessonCount:row.document.lessons.length,validationErrors:errors,allPathsInCurrentSitemap:true,paths,editorialAttribution:row.document.editorial,limitation:'Public snapshot metadata is not independent proof of who approved or deployed the backend revision.'}});
// Integer cents avoid binary floating-point artifacts (e.g. 80000*1.001).
assert.equal(2*4000000+8000,8008000);
assert.equal(10000000-8008000+2*4100000,10192000);
assert.equal(510000-510-500500,8990);
assert.equal(490000-490-500500,-10990);
assert.equal((110000-88000)*100/110000,20);
assert.equal((88000-100000)*100/100000,-12);
assert.equal(192*(500+10+9.5),99744);
assert.equal(.25*500,125);
const evidence={observedAt:new Date().toISOString(),method:'Anonymous public read only; no private draft reads, mutations or publishing',courses:rows,arithmetic:'PASS using integer cents: Bitcoin buy/sell fees, adverse/favorable invented outcomes, drawdown/starting-return denominators, fee-aware risk budget, MES tick',limits:'Structural validation and stated arithmetic do not certify every claim, originality, professional accuracy, Google approval, or backend deployment identity.'};writeFileSync('/workspace/work/tradehq-adsense/docs/audits/adsense-2026-11-14/evidence/published-course-assessment.json',JSON.stringify(evidence,null,2)+'\n');console.log(JSON.stringify({courses:rows.length,lessons:rows.reduce((n,r)=>n+r.lessonCount,0),arithmetic:evidence.arithmetic}));
